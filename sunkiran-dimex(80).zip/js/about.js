/* ==========================================================================
   Sunkiran Dimex - About Page Interactive & Motion Scripts
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initStickyHeader();
  initMobileMenu();
  initParallaxEffects();
  initScrollReveals();
});

/**
 * Sticky Header Scroll State
 */
function initStickyHeader() {
  const header = document.querySelector('.site-header');
  if (!header) return;

  const handleScroll = () => {
    if (window.scrollY > 20) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  };

  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();
}

/**
 * Mobile Drawer Menu with Accessibility & Focus Trap
 */
function initMobileMenu() {
  const menuBtn = document.querySelector('.mobile-menu-btn');
  const drawerOverlay = document.querySelector('.mobile-drawer-overlay');
  const closeBtn = document.querySelector('.drawer-close-btn');
  const drawerLinks = document.querySelectorAll('.drawer-link, .mobile-drawer .btn-cta-primary');

  if (!menuBtn || !drawerOverlay) return;

  const openMenu = () => {
    drawerOverlay.classList.add('open');
    drawerOverlay.setAttribute('aria-hidden', 'false');
    menuBtn.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    if (closeBtn) closeBtn.focus();
  };

  const closeMenu = () => {
    drawerOverlay.classList.remove('open');
    drawerOverlay.setAttribute('aria-hidden', 'true');
    menuBtn.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    menuBtn.focus();
  };

  menuBtn.addEventListener('click', openMenu);
  if (closeBtn) closeBtn.addEventListener('click', closeMenu);

  drawerOverlay.addEventListener('click', (e) => {
    if (e.target === drawerOverlay) {
      closeMenu();
    }
  });

  drawerLinks.forEach(link => {
    link.addEventListener('click', closeMenu);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawerOverlay.classList.contains('open')) {
      closeMenu();
    }
  });
}

/**
 * Subtle pointer parallax on hero floating cards for desktop
 */
function initParallaxEffects() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  if (window.innerWidth < 1024) return;

  const heroRight = document.querySelector('.hero-right');
  const metaBadge = document.querySelector('.floating-meta-badge');
  const metricsCard = document.querySelector('.floating-metrics-card');

  if (!heroRight) return;

  heroRight.addEventListener('mousemove', (e) => {
    const rect = heroRight.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;

    if (metaBadge) {
      metaBadge.style.transform = `translate(${x * 16}px, ${y * 16}px)`;
    }
    if (metricsCard) {
      metricsCard.style.transform = `translateY(-50%) translate(${x * -20}px, ${y * -20}px)`;
    }
  });

  heroRight.addEventListener('mouseleave', () => {
    if (metaBadge) metaBadge.style.transform = '';
    if (metricsCard) metricsCard.style.transform = '';
  });
}

/**
 * Scroll Triggered Entrance Animations
 */
function initScrollReveals() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

  if (typeof gsap !== 'undefined' && typeof ScrollTrigger !== 'undefined') {
    gsap.registerPlugin(ScrollTrigger);

    // Hero entrance
    const heroTl = gsap.timeline({ defaults: { ease: 'power3.out', duration: 0.8 } });
    heroTl
      .from('.hero-left .pill-eyebrow', { opacity: 0, y: 20, duration: 0.5 })
      .from('.hero-h1', { opacity: 0, y: 30, duration: 0.8 }, '-=0.3')
      .from('.hero-subheadline', { opacity: 0, y: 20, duration: 0.6 }, '-=0.5')
      .from('.hero-body', { opacity: 0, y: 20, duration: 0.6 }, '-=0.4')
      .from('.fact-card', { opacity: 0, y: 20, stagger: 0.12, duration: 0.6 }, '-=0.3')
      .from('.hero-right', { opacity: 0, scale: 0.95, duration: 0.9 }, '-=0.8')
      .from('.floating-meta-badge', { opacity: 0, scale: 0.8, duration: 0.6 }, '-=0.4')
      .from('.floating-metrics-card', { opacity: 0, x: 30, duration: 0.6 }, '-=0.4')
      .from('.hero-annotation-wrap', { opacity: 0, y: -15, duration: 0.6 }, '-=0.3');

    // Who We Are entrance
    gsap.from('.who-visual-wrap', {
      scrollTrigger: {
        trigger: '.who-we-are-section',
        start: 'top 75%',
      },
      opacity: 0,
      x: -40,
      duration: 0.9,
      ease: 'power3.out'
    });

    gsap.from('.who-content', {
      scrollTrigger: {
        trigger: '.who-we-are-section',
        start: 'top 75%',
      },
      opacity: 0,
      x: 40,
      duration: 0.9,
      ease: 'power3.out'
    });

    // What We Do Cards (staggered)
    gsap.from('.service-card', {
      scrollTrigger: {
        trigger: '.services-grid',
        start: 'top 80%',
      },
      opacity: 0,
      y: 35,
      stagger: 0.1,
      duration: 0.7,
      ease: 'power3.out'
    });

    // Commitment zones
    gsap.from('.commitment-visual-zone', {
      scrollTrigger: {
        trigger: '.commitment-section',
        start: 'top 80%',
      },
      opacity: 0,
      scale: 0.85,
      duration: 0.8,
      ease: 'back.out(1.7)'
    });

    gsap.from('.commitment-content-zone', {
      scrollTrigger: {
        trigger: '.commitment-section',
        start: 'top 80%',
      },
      opacity: 0,
      y: 30,
      duration: 0.8,
      ease: 'power3.out'
    });

    gsap.from('.principle-item', {
      scrollTrigger: {
        trigger: '.commitment-principles-zone',
        start: 'top 85%',
      },
      opacity: 0,
      x: 30,
      stagger: 0.12,
      duration: 0.6,
      ease: 'power3.out'
    });

    // CTA Banner
    gsap.from('.cta-banner-card', {
      scrollTrigger: {
        trigger: '.footer-cta-section',
        start: 'top 85%',
      },
      opacity: 0,
      y: 30,
      duration: 0.8,
      ease: 'power3.out'
    });
  }
}
